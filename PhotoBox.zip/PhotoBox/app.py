import os
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = 'your-secret-key-change-in-production'

# Configuration
UPLOAD_FOLDER = 'static/uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}
MAX_FILE_SIZE = 16 * 1024 * 1024  # 16MB

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE

# Create upload folder if it doesn't exist
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route('/')
def index():
    """Render upload page."""
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload():
    """Handle file upload."""
    # Check if file is in request
    if 'photo' not in request.files:
        flash('No file selected', 'error')
        return redirect(url_for('index'))
    
    file = request.files['photo']
    
    # Check if filename is empty
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(url_for('index'))
    
    # Validate and save file
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        
        # Handle duplicate filenames
        base_name, extension = os.path.splitext(filename)
        counter = 1
        while os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'], filename)):
            filename = f"{base_name}_{counter}{extension}"
            counter += 1
        
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        try:
            # Save original file without any processing
            file.save(filepath)
            flash('Photo uploaded successfully!', 'success')
            return redirect(url_for('gallery'))
        except Exception as e:
            flash(f'Upload failed: {str(e)}', 'error')
            return redirect(url_for('index'))
    else:
        flash('Invalid file type. Please upload PNG, JPG, JPEG, GIF, or WEBP', 'error')
        return redirect(url_for('index'))


@app.route('/gallery')
def gallery():
    """Display all uploaded images."""
    try:
        images = [f for f in os.listdir(app.config['UPLOAD_FOLDER']) 
                  if allowed_file(f)]
        images.sort(key=lambda x: os.path.getmtime(
            os.path.join(app.config['UPLOAD_FOLDER'], x)), reverse=True)
        return render_template('gallery.html', images=images)
    except Exception as e:
        flash(f'Error loading gallery: {str(e)}', 'error')
        return render_template('gallery.html', images=[])


@app.route('/image/<filename>')
def view_image(filename):
    """Display single image in full screen."""
    # Security: verify file exists and is allowed
    if not allowed_file(filename):
        flash('Invalid file', 'error')
        return redirect(url_for('gallery'))
    
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    if not os.path.exists(filepath):
        flash('Image not found', 'error')
        return redirect(url_for('gallery'))
    
    return render_template('view.html', filename=filename)


@app.errorhandler(413)
def too_large(e):
    """Handle file too large error."""
    flash('File is too large. Maximum size is 16MB', 'error')
    return redirect(url_for('index'))


@app.errorhandler(404)
def not_found(e):
    """Handle 404 errors."""
    return redirect(url_for('index'))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)))
